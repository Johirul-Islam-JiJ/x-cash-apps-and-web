<footer class="footer-section">
    <div class="footer-section__bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>{{date('Y')}} © {{__($general->site_name)}}. @lang('All Right Reserved')</p>
                </div>
            </div>
        </div>
    </div>
</footer>